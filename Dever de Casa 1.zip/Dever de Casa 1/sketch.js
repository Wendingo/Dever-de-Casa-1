var box;

function setup() {
  createCanvas(400,400);
  
  box = createSprite(200,200, 20, 20);

  box.shapeColor = "white";
}

function draw() 
{
  background("black");
  if(keyDown("d")){
    box.position.x += 5;
    background("red");
  }
  if(keyDown("a")){
    box.position.x -= 5;
    background("green");
  }
  drawSprites();
}
